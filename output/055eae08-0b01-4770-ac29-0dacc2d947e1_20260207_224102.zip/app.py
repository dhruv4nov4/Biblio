from flask import Flask, jsonify, request, send_from_directory, abort
from flask_cors import CORS
import chess
import chess.svg
import random
import copy

app = Flask(__name__, static_folder='static')
CORS(app)

# Global game state
class Game:
    def __init__(self):
        self.board = chess.Board()
        self.history = []          # Stack of previous board states for undo
        self.redo_stack = []       # Stack for redo
        self.save_states = {}      # Simple in‑memory saves keyed by name

    def reset(self):
        self.board.reset()
        self.history.clear()
        self.redo_stack.clear()

    def push_state(self):
        # Store a deep copy of the board for undo
        self.history.append(self.board.copy(stack=False))
        # Clear redo stack on new move
        self.redo_stack.clear()

    def undo(self):
        if not self.history:
            return False
        self.redo_stack.append(self.board.copy(stack=False))
        self.board = self.history.pop()
        return True

    def redo(self):
        if not self.redo_stack:
            return False
        self.history.append(self.board.copy(stack=False))
        self.board = self.redo_stack.pop()
        return True

    def to_matrix(self):
        # Returns an 8x8 list with piece symbols or empty strings
        board_matrix = []
        for rank in range(8, 0, -1):
            row = []
            for file in range(1, 9):
                square = chess.square(file - 1, rank - 1)
                piece = self.board.piece_at(square)
                row.append(piece.symbol() if piece else "")
            board_matrix.append(row)
        return board_matrix

    def status(self):
        if self.board.is_checkmate():
            return "checkmate"
        if self.board.is_stalemate():
            return "stalemate"
        if self.board.is_check():
            return "check"
        return "ongoing"

game = Game()

# ---------- Helper Functions ----------
def evaluate_board(board):
    """Simple material evaluation."""
    piece_values = {
        chess.PAWN: 1,
        chess.KNIGHT: 3,
        chess.BISHOP: 3,
        chess.ROOK: 5,
        chess.QUEEN: 9,
        chess.KING: 0
    }
    score = 0
    for piece_type in piece_values:
        score += len(board.pieces(piece_type, chess.WHITE)) * piece_values[piece_type]
        score -= len(board.pieces(piece_type, chess.BLACK)) * piece_values[piece_type]
    return score

def minimax(board, depth, is_maximizing):
    if depth == 0 or board.is_game_over():
        return evaluate_board(board), None

    best_move = None
    if is_maximizing:
        max_eval = -float('inf')
        for move in board.legal_moves:
            board.push(move)
            eval_score, _ = minimax(board, depth - 1, False)
            board.pop()
            if eval_score > max_eval:
                max_eval = eval_score
                best_move = move
        return max_eval, best_move
    else:
        min_eval = float('inf')
        for move in board.legal_moves:
            board.push(move)
            eval_score, _ = minimax(board, depth - 1, True)
            board.pop()
            if eval_score < min_eval:
                min_eval = eval_score
                best_move = move
        return min_eval, best_move

def generate_ai_move(difficulty):
    """Return a chess.Move object based on difficulty."""
    if difficulty == 1:
        # Easy: random legal move
        return random.choice(list(game.board.legal_moves))
    elif difficulty == 2:
        # Medium: minimax depth 2
        _, move = minimax(game.board, 2, game.board.turn == chess.WHITE)
        return move
    elif difficulty == 3:
        # Hard: minimax depth 3
        _, move = minimax(game.board, 3, game.board.turn == chess.WHITE)
        return move
    else:
        # Default to random if unknown difficulty
        return random.choice(list(game.board.legal_moves))

# ---------- Routes ----------
@app.route('/', methods=['GET'])
def serve_index():
    return send_from_directory('.', 'index.html')

@app.route('/static/<path:filename>', methods=['GET'])
def serve_static(filename):
    return send_from_directory(app.static_folder, filename)

@app.route('/api/state', methods=['GET'])
def get_state():
    return jsonify({
        "board": game.to_matrix(),
        "turn": "white" if game.board.turn == chess.WHITE else "black",
        "status": game.status(),
        "legal_moves": [game.board.san(m) for m in game.board.legal_moves]
    })

@app.route('/api/move', methods=['POST'])
def make_move():
    data = request.get_json()
    if not data or 'from' not in data or 'to' not in data:
        abort(400, description="Missing 'from' or 'to' fields.")
    try:
        move = game.board.parse_san(data.get('san')) if 'san' in data else game.board.parse_uci(f"{data['from']}{data['to']}")
    except ValueError:
        abort(400, description="Invalid move format.")
    if move not in game.board.legal_moves:
        abort(400, description="Illegal move.")
    game.push_state()
    game.board.push(move)
    return jsonify({
        "board": game.to_matrix(),
        "turn": "white" if game.board.turn == chess.WHITE else "black",
        "status": game.status(),
        "last_move": game.board.san(move)
    })

@app.route('/api/undo', methods=['POST'])
def undo_move():
    if not game.undo():
        abort(400, description="No moves to undo.")
    return jsonify({
        "board": game.to_matrix(),
        "turn": "white" if game.board.turn == chess.WHITE else "black",
        "status": game.status()
    })

@app.route('/api/redo', methods=['POST'])
def redo_move():
    if not game.redo():
        abort(400, description="No moves to redo.")
    return jsonify({
        "board": game.to_matrix(),
        "turn": "white" if game.board.turn == chess.WHITE else "black",
        "status": game.status()
    })

@app.route('/api/save', methods=['POST'])
def save_game():
    data = request.get_json()
    name = data.get('name')
    if not name:
        abort(400, description="Save name required.")
    # Store FEN representation
    game.save_states[name] = game.board.fen()
    return jsonify({"message": f"Game saved as '{name}'."})

@app.route('/api/load', methods=['POST'])
def load_game():
    data = request.get_json()
    name = data.get('name')
    if not name or name not in game.save_states:
        abort(400, description="Invalid or missing save name.")
    fen = game.save_states[name]
    game.board.set_fen(fen)
    game.history.clear()
    game.redo_stack.clear()
    return jsonify({
        "board": game.to_matrix(),
        "turn": "white" if game.board.turn == chess.WHITE else "black",
        "status": game.status(),
        "message": f"Game '{name}' loaded."
    })

@app.route('/api/reset', methods=['POST'])
def reset_game():
    game.reset()
    return jsonify({
        "board": game.to_matrix(),
        "turn": "white",
        "status": game.status(),
        "message": "Game reset."
    })

@app.route('/api/ai_move', methods=['GET'])
def ai_move():
    try:
        difficulty = int(request.args.get('difficulty', 1))
    except ValueError:
        difficulty = 1
    if game.board.is_game_over():
        abort(400, description="Game is already over.")
    move = generate_ai_move(difficulty)
    if move is None:
        abort(500, description="AI could not generate a move.")
    game.push_state()
    game.board.push(move)
    return jsonify({
        "board": game.to_matrix(),
        "turn": "white" if game.board.turn == chess.WHITE else "black",
        "status": game.status(),
        "ai_move": game.board.san(move)
    })

# ---------- Error Handlers ----------
@app.errorhandler(400)
def bad_request(error):
    return jsonify({"error": "Bad Request", "message": error.description}), 400

@app.errorhandler(404)
def not_found(error):
    return jsonify({"error": "Not Found", "message": "The requested resource was not found."}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({"error": "Internal Server Error", "message": str(error)}), 500

# ---------- Run ----------
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)