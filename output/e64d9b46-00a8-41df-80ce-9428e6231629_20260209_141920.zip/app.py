from flask import Flask, request, jsonify, send_from_directory, abort
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, date
import os

app = Flask(__name__, static_folder='static', static_url_path='/static')
CORS(app)

# Database configuration
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{os.path.join(BASE_DIR, "health_tracker.db")}'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)


# -------------------- Models --------------------
class Activity(db.Model):
    __tablename__ = 'activities'
    id = db.Column(db.Integer, primary_key=True)
    activity_date = db.Column(db.Date, nullable=False, default=date.today)
    type = db.Column(db.String(50), nullable=False)   # e.g., exercise, sleep, nutrition
    value = db.Column(db.String(200), nullable=False)  # free‑form value (e.g., "30 min", "8 hrs", "2000 kcal")

    def to_dict(self):
        return {
            "id": self.id,
            "date": self.activity_date.isoformat(),
            "type": self.type,
            "value": self.value
        }


class Goal(db.Model):
    __tablename__ = 'goals'
    id = db.Column(db.Integer, primary_key=True)
    type = db.Column(db.String(50), nullable=False)   # e.g., weight, steps, calories
    target = db.Column(db.String(100), nullable=False)  # target description/value
    progress = db.Column(db.String(100), nullable=True)  # current progress
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "type": self.type,
            "target": self.target,
            "progress": self.progress,
            "created_at": self.created_at.isoformat()
        }


class Reminder(db.Model):
    __tablename__ = 'reminders'
    id = db.Column(db.Integer, primary_key=True)
    message = db.Column(db.String(200), nullable=False)
    remind_at = db.Column(db.DateTime, nullable=False)
    enabled = db.Column(db.Boolean, default=True)

    def to_dict(self):
        return {
            "id": self.id,
            "message": self.message,
            "remind_at": self.remind_at.isoformat(),
            "enabled": self.enabled
        }


# -------------------- Helper Functions --------------------
def init_db():
    """Create tables if they don't exist."""
    db.create_all()


# -------------------- Routes --------------------
@app.route('/', methods=['GET'])
def serve_index():
    """Serve the main HTML page."""
    return send_from_directory('.', 'index.html')


@app.route('/static/<path:filename>', methods=['GET'])
def serve_static(filename):
    """Serve static assets (CSS, JS, images)."""
    return send_from_directory(app.static_folder, filename)


# ----- Daily Activity Tracking -----
@app.route('/api/activities', methods=['GET', 'POST'])
def activities():
    if request.method == 'GET':
        activities = Activity.query.order_by(Activity.activity_date.desc()).all()
        return jsonify([a.to_dict() for a in activities]), 200

    if request.method == 'POST':
        data = request.get_json()
        try:
            activity_date = datetime.strptime(data.get('date'), '%Y-%m-%d').date() if data.get('date') else date.today()
            new_activity = Activity(
                activity_date=activity_date,
                type=data['type'],
                value=data['value']
            )
            db.session.add(new_activity)
            db.session.commit()
            return jsonify(new_activity.to_dict()), 201
        except (KeyError, ValueError) as e:
            return jsonify({"error": f"Invalid payload: {str(e)}"}), 400


# ----- Goal Setting -----
@app.route('/api/goals', methods=['GET', 'POST', 'PUT', 'DELETE'])
def goals():
    if request.method == 'GET':
        goals = Goal.query.order_by(Goal.created_at.desc()).all()
        return jsonify([g.to_dict() for g in goals]), 200

    if request.method == 'POST':
        data = request.get_json()
        try:
            new_goal = Goal(
                type=data['type'],
                target=data['target'],
                progress=data.get('progress')
            )
            db.session.add(new_goal)
            db.session.commit()
            return jsonify(new_goal.to_dict()), 201
        except KeyError as e:
            return jsonify({"error": f"Missing field: {str(e)}"}), 400

    if request.method == 'PUT':
        data = request.get_json()
        try:
            goal = Goal.query.get_or_404(data['id'])
            goal.type = data.get('type', goal.type)
            goal.target = data.get('target', goal.target)
            goal.progress = data.get('progress', goal.progress)
            db.session.commit()
            return jsonify(goal.to_dict()), 200
        except KeyError as e:
            return jsonify({"error": f"Missing field: {str(e)}"}), 400

    if request.method == 'DELETE':
        data = request.get_json()
        try:
            goal = Goal.query.get_or_404(data['id'])
            db.session.delete(goal)
            db.session.commit()
            return jsonify({"message": "Goal deleted"}), 200
        except Exception as e:
            return jsonify({"error": str(e)}), 400


# ----- Progress Analytics -----
@app.route('/api/analytics', methods=['GET'])
def analytics():
    """Return simple aggregated analytics."""
    try:
        # Example: count activities per type over the last 30 days
        thirty_days_ago = date.today() - datetime.timedelta(days=30)
        activities = Activity.query.filter(Activity.activity_date >= thirty_days_ago).all()

        analytics_data = {}
        for act in activities:
            analytics_data.setdefault(act.type, 0)
            analytics_data[act.type] += 1

        # Goal completion ratio (simple approximation)
        total_goals = Goal.query.count()
        completed_goals = Goal.query.filter(Goal.progress == Goal.target).count()
        goal_completion = (completed_goals / total_goals * 100) if total_goals else 0

        return jsonify({
            "activity_counts_last_30_days": analytics_data,
            "goal_completion_percent": round(goal_completion, 2)
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ----- Reminders and Notifications -----
@app.route('/api/reminders', methods=['GET', 'POST', 'PUT', 'DELETE'])
def reminders():
    if request.method == 'GET':
        reminders = Reminder.query.order_by(Reminder.remind_at.asc()).all()
        return jsonify([r.to_dict() for r in reminders]), 200

    if request.method == 'POST':
        data = request.get_json()
        try:
            remind_at = datetime.fromisoformat(data['remind_at'])
            new_reminder = Reminder(
                message=data['message'],
                remind_at=remind_at,
                enabled=data.get('enabled', True)
            )
            db.session.add(new_reminder)
            db.session.commit()
            return jsonify(new_reminder.to_dict()), 201
        except (KeyError, ValueError) as e:
            return jsonify({"error": f"Invalid payload: {str(e)}"}), 400

    if request.method == 'PUT':
        data = request.get_json()
        try:
            reminder = Reminder.query.get_or_404(data['id'])
            reminder.message = data.get('message', reminder.message)
            if 'remind_at' in data:
                reminder.remind_at = datetime.fromisoformat(data['remind_at'])
            reminder.enabled = data.get('enabled', reminder.enabled)
            db.session.commit()
            return jsonify(reminder.to_dict()), 200
        except (KeyError, ValueError) as e:
            return jsonify({"error": f"Invalid payload: {str(e)}"}), 400

    if request.method == 'DELETE':
        data = request.get_json()
        try:
            reminder = Reminder.query.get_or_404(data['id'])
            db.session.delete(reminder)
            db.session.commit()
            return jsonify({"message": "Reminder deleted"}), 200
        except Exception as e:
            return jsonify({"error": str(e)}), 400


# ----- Social Sharing -----
@app.route('/api/share', methods=['POST'])
def share():
    """
    Mock endpoint for social sharing.
    Expects JSON with 'platform' (e.g., 'twitter') and 'content'.
    Returns a fake shareable URL.
    """
    data = request.get_json()
    try:
        platform = data['platform'].lower()
        content = data['content']
        # In a real app, you'd integrate with platform SDKs/APIs.
        fake_url = f"https://social.example.com/share/{platform}/{datetime.utcnow().timestamp()}"
        return jsonify({
            "platform": platform,
            "content": content,
            "share_url": fake_url,
            "status": "shared"
        }), 200
    except KeyError as e:
        return jsonify({"error": f"Missing field: {str(e)}"}), 400


# -------------------- Error Handlers --------------------
@app.errorhandler(404)
def not_found(error):
    return jsonify({"error": "Resource not found"}), 404


@app.errorhandler(500)
def internal_error(error):
    return jsonify({"error": "Internal server error"}), 500


# -------------------- Application Entry Point --------------------
if __name__ == '__main__':
    init_db()
    # Use host='0.0.0.0' for containerized environments
    app.run(host='0.0.0.0', port=5000, debug=False)